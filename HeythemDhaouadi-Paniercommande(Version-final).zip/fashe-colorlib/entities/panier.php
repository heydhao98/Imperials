<?PHP
/*----------------------------------------------------------=Class=--------------------------------------------------------------*/
class panier{
	
	private $id_produit;
	private $quantite;
	private $id_client;
	private $taille;
	private $prix;


    
/*--------------------------------------------------------=Constructeur=--------------------------------------------------------------*/
	function __construct($id_produit,$quantite,$id_client,$taille,$prix){
		
		$this->id_produit=$id_produit;
		$this->quantite=$quantite;
		$this->id_client=$id_client;
		$this->taille=$taille;
		$this->prix=$prix;

	}
	
	/*----------------------------------------------------------=Getters=--------------------------------------------------------------*/

	
	function getid_produit(){
		return $this->id_produit;
	}
	function getquantite(){
		return $this->quantite;
	}
		function getid_client(){
		return $this->id_client;
	}
	function gettaille(){
		return $this->taille;
	}
	function getprix(){
		return $this->prix;
	}
	
	
/*----------------------------------------------------------=Setters=--------------------------------------------------------------*/

	
	function setid_produit($id_produit){
		$this->id_produit=$id_produit;
	}
	function setquantite($quantite){
		$this->quantite=$quantite;
	}
	function setid_client($id_client){
		$this->id_client=$id_client;
	}
	function settaille($taille){
		$this->taille=$taille;
	}
	function setprix($prix){
		$this->prix=$prix;
	}

	
}

?>