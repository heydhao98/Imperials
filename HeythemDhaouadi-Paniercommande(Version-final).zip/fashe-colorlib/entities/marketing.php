<?php
class fete 
{
  private $id_fete;
  private $nom;
  private $pourcentage_reduction;
  private $date_debut;
  private $date_fin;
  private $nom_prod;

}
function _construct ($id_fete,$nom,$pourcentage_reduction,$date_debut,$date_fin,$nom_produit)
{
    $this->id_fete= $id_fete;
    $this->nom= $nom;
    $this->pourcentage_reduction= $pourcentage_reduction;
    $this->date_debut= $date_debut;
    $this->date_fin= $date_fin;
    $this->nom_produit= $nom_produit;
}
function getid()
{
    return $this->id_fete;
}
function setid($id_fete)
{
    $this->id_fete=$id_fete;
}
function getnom()
{
    return $this->nom;
}
function setnom ($nom)
{
    $this->nom=$nom;
}
function getpourcentage()
{
    return $this->pourcentage_reduction;
}
function setpourcentage($pourcentage_reduction)
{
    $this->pourcentage_reduction=$pourcentage_reduction;
}
function getdatedebut ()
{
    return $this->date_debut;
}
function set ($date_debut)
{
   $this->date_debut=$date_debut;
}
function getdatefin ()
{
    return $this->date_fin;
}
function set ($date_fin)
{
    $this->date_fin=$date_fin;
}
function getnom_prod ()
{
    return $this->nom_prod;
}
function setnom_prod ($nom_prod)
{
    $this->nom_prod=$nom_prod;
}
?>
