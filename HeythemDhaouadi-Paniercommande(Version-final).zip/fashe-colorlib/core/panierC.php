<?PHP
include "../config.php";
class panierC {
function afficherpanier ($panier){
		echo "id_client: ".$panier->getid_client()."<br>";
		echo "prix: ".$panier->getprix()."<br>";
		echo "id_produit: ".$panier->getid_produit()."<br>";
		echo "taille: ".$panier->gettaille()."<br>";
		
		echo "quantite: ".$panier->quantite()."<br>";

	}


function ajouterpanier($panier){
		$sql="insert into panier (id_client,id_produit,prix,taille,quantite) values (:id_client,:id_produit,:prix,:taille,:quantite)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);//prépare la requete sql à etre exécuté par
        $id_client=$panier->getid_client();
        
        $prix=$panier->getprix();
        $id_produit=$panier->getid_produit();
        $taille=$panier->gettaille();
        
        $quantite=$panier->getquantite();
		$req->bindValue(':id_client',$id_client);
		
		$req->bindValue(':prix',$prix);
		$req->bindValue(':id_produit',$id_produit);
		$req->bindValue(':taille',$taille);
		
		$req->bindValue(':quantite',$quantite);
         
         if( $req->execute()){
         	return 1;
         }else{
         	return 0;
         }
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

function deletepanier($id_panier){
		$sql="DELETE FROM panier where id_panier= :id_panier";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id_panier',$id_panier);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	public static function modifierpanier($id_produit,$argument,$valeur){
		$sql="UPDATE panier SET ".$argument."=:".$argument." WHERE id_produit=:id_produit";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
		if(strtolower($argument)=="new"){
			$valeur=intval($valeur);
		}
try{		
        $req=$db->prepare($sql);
         $s=$req->execute([
			":id_produit"=>intval($id_produit),
			":".$argument=>$valeur]);
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function tricroissant(){
		$sql="SElECT * From panier order by prix";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

function tridecroissant(){
		$sql="SElECT * From panier order by prix DESC";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}


function afficherpaniers(){
		$sql="SElECT * From panier";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

}