<?php
include "../config.php";
class marketingC
{
   function afficher_fete ($fete)
  { echo "nom fete : " .$fete->getnom() "<br>";
   echo "pourcentage de reduction : " .$fete->getpourcentage() "<br>";
   echo "date du debut de la reduction: " .$fete->getdatedebut() "<br>";
   echo "date de fin de la reduction: " .$fete->getdatefin() "<br>";
   echo "le nom du produit concerné par la reduction: " .$fete->getnom_produit() "<br>";
  }
  function ajouterfete($fete){
		$sql="insert into fete (nom,pourcentage_reduction,date_debut,date_fin,nom_prod) values (:nom,:pourcentage_reduction,:date_debut,:date_fin,:nom_prod)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);//prépare la requete sql à etre exécuté par
        $nom=$fete->getnom();
        $pourcentage_reduction=$fete-> getpourcentage();
        $date_debut=$fete->getdatedebut();
        $date_fin=$date_fin->getdatefin();
        $nom_prod=$produit->getnom_prod();
		$req->bindValue(':nom',$nom);
		$req->bindValue(':pourcentage_reduction',$pourcentage_reduction);
		$req->bindValue(':date_debut',$date_debut);
		$req->bindValue(':date_fin',$date_fin);
    $req->bindValue(':nom_prod',$nom_prod);
         
         if( $req->execute()){
         	return 1;
         }else{
         	return 0;
         }
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

  
function deleteproduit($id_fete){
  $sql="DELETE FROM fete where id_fete= :id_fete";
  $db = config::getConnexion();
      $req=$db->prepare($sql);
  $req->bindValue(':id_fete',$id_fete);
  try{
          $req->execute();
         // header('Location: index.php');
      }
      catch (Exception $e){
          die('Erreur: '.$e->getMessage());
      }
}

}

public static function modifierfete($id_fete,$argument,$valeur){
  $sql="UPDATE fete SET ".$argument."=:".$argument." WHERE id_fete=:id_fete";
  
  $db = config::getConnexion();
  //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
  if(strtolower($argument)=="new"){
    $valeur=intval($valeur);
  }
try{		
      $req=$db->prepare($sql);
       $s=$req->execute([
    ":id_fete"=>intval($id_fete),
    ":".$argument=>$valeur]);
         // header('Location: index.php');
      }
      catch (Exception $e){
          echo " Erreur ! ".$e->getMessage();
 echo " Les datas : " ;
print_r($datas);
      }
  
}
function afficherfetes(){
  $sql="SElECT * From fete";
  $db = config::getConnexion();
  try{
  $liste=$db->query($sql);
  return $liste;
  }
      catch (Exception $e){
          die('Erreur: '.$e->getMessage());
      }	
}
?>