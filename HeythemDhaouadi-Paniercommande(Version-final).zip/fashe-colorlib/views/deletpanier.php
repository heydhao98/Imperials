<?php
include "../entities/panier.php";
include "../core/panierC.php";
      $panierC= new panierC();
      $panierC->deletepanier($_GET["id"]);
      header('location: ' . $_SERVER['HTTP_REFERER']);
      ?>
