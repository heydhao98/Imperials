<?PHP
include "../entities/panier.php";
include "../core/panierC.php";

function verifier($tableau){
	foreach ($tableau as $key => $value) {
		if(!isset($_POST[$value])){
			return false;
		}
	}
	return true;
}

if(verifier(['id_client','id_produit','prix','taille','quantite'])){

$panier1=new panier($_POST['id_client'],$_POST['id_produit'],$_POST['prix'],$_POST['taille'],$_POST['quantite']);

$panier1C=new panierC();
if($panier1C->ajouterpanier($panier1)){
	 

 


	header('Location: panier.php');	
}




	
}
//*/
