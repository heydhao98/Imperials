<?PHP
include "../config.php";
class ProduitC {
function afficherProduit ($produit){
		echo "nom du prod: ".$produit->getnom_prod()."<br>";
		echo "description: ".$produit->getdescription()."<br>";
		echo "prix: ".$produit->getprix()."<br>";
		echo "photo: ".$produit->getphoto()."<br>";
		echo "taille: ".$produit->gettaille()."<br>";
		echo "couleur: ".$produit->getcouleur()."<br>";
		echo "stock: ".$produit->stock()."<br>";

	}


function ajouterProduit($produit){
		$sql="insert into produit (nom_prod,description,prix,photo,taille,couleur,stock) values (:nom_prod,:description,:prix,:photo,:taille,:couleur,:stock)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);//prépare la requete sql à etre exécuté par
        $nom_prod=$produit->getnom_prod();
        $description=$produit->getdescription();
        $prix=$produit->getprix();
        $photo=$produit->getphoto();
        $taille=$produit->gettaille();  
        $couleur=$produit->getcouleur();
        $stock=$produit->getstock();
		$req->bindValue(':nom_prod',$nom_prod);
		$req->bindValue(':description',$description);
		$req->bindValue(':prix',$prix_prod);
		$req->bindValue(':photo',$photo);
		$req->bindValue(':taille',$taille);
		$req->bindValue(':couleur',$couleur);
		$req->bindValue(':stock',$stock);
         
         if( $req->execute()){
         	return 1;
         }else{
         	return 0;
         }
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}

function deleteproduit($id_prod){
		$sql="DELETE FROM produit where id_prod= :id_prod";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id_prod',$id_prod);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}

	public static function modifierproduit($id_prod,$argument,$valeur){
		$sql="UPDATE produit SET ".$argument."=:".$argument." WHERE id_prod=:id_prod";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
		if(strtolower($argument)=="new"){
			$valeur=intval($valeur);
		}
try{		
        $req=$db->prepare($sql);
         $s=$req->execute([
			":id_prod"=>intval($id_prod),
			":".$argument=>$valeur]);
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}


function afficherproduits(){
		$sql="SElECT * From produit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}

}