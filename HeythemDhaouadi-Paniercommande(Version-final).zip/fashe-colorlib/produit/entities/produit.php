<?PHP 
class Produit{
private $nom_prod; 
private $description;
private $prix ; 
private $photo ; 
private $taille ; 
private $couleur ; 
private $stock ; 


/*----------------------------------------Constructer--------------------------------------------------------------*/ 

function _construct($nom_prod,$description,$prix,$photo,$taille,$couleur,$stock){
$this->nom_prod=$nom_prod;
$this->description=$description;
$this->prix=$prix ;
$this->photo=$photo; 
$this->taille=$taille ; 
$this->couleur=$couleur ; 
$this->stock=$stock ; 
}

/*----------------------------------------Getters--------------------------------------------------------------*/ 

	function getnom_prod(){
		return $this->nom_prod;
	}
	function getdescription(){
		return $this->description;
	}
	function getprix(){
		return $this->prix;
	}
	function getphoto(){
		return $this->photo;
	}
    function gettaille(){
    	return $this->taille; 
    }
    function getcouleur(){
    	return $this->couleur;
    } 
    function getstock(){
    	return $this->stock ;
    }

function setnom_prod($nom_prod){
		$this->nom_prod=$nom_prod;
	}
	function setdescription($description){
		$this->description=$description;
	}
	function setprix($prix){
		$this->prix_prod=$prix_prod;
	}
	function setphoto($photo){
		$this->photo=$photo;
	}
	
	function settaille($taille){
		$this->taille=$taille;
	}
	function setcouleur($couleur){
		$this->couleur=$couleur;
	}
   function setstock($stock){
   		$this->stock=$stock; 
   }

	
	
}

?>